#include <iostream>
#include <deque>
#include <string>
#include <functional>
#include <algorithm>
using namespace std;
int main() {
	deque<pair<int, string>> a(2, make_pair<int, string>(-1, "NULL")); // a.size()==2,
	a[i] = "NULL"
		deque<pair<int, string>> b;
	a.push_front(make_pair<int, string>(1, "Mot"));
	a.push_front(make_pair<int, string>(2, "Hai"));
	b = a; // g�n n?i dung c?a a v�o b
	while (!b.empty()) {
		pair<int, string> v = b.front();
		b.pop_front();
		cout << "(" << v.first << "," << v.second << ")";
	}
	return 0;
}